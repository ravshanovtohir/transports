export default {
    Query: {
        user: () => "Ali"
    }
}